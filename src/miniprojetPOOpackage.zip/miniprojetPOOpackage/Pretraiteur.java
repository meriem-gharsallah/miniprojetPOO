package miniprojetPOOpackage;
import java.util.List;

public interface Pretraiteur {
	
	List<Nom> pretraiter(List<Nom> noms);
}
