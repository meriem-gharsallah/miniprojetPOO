package miniprojetPOOpackage;
import java.util.List;

public class SelectionneurAleatoire implements SelectionneurDeResultats {

 
	public List<CoupleDeNomsAvecScore> selectionner(List<CoupleDeNomsAvecScore> noms) {
		return noms;
	}
}
