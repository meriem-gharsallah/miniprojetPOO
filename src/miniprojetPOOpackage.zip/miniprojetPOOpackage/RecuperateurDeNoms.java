package miniprojetPOOpackage;
import java.util.List;

public interface RecuperateurDeNoms {
	List<Nom> recuperer();
	 

}