package miniprojetPOOpackage;

import java.util.List;

public interface GenerateurDeCandidats {
	
	List<CoupleDeNoms> generer(List<Nom> liste1, List<Nom> liste2);
	
	

}
