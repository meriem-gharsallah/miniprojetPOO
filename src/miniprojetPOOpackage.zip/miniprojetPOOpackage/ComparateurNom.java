package miniprojetPOOpackage;

public interface ComparateurNom {
	double comparer(Nom n1, Nom n2);

}
