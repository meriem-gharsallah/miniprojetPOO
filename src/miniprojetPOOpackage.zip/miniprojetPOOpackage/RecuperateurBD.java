package miniprojetPOOpackage;

import java.util.List;

public class RecuperateurBD implements RecuperateurDeNoms {

	public RecuperateurBD() {

	}

	@Override
	public List<Nom> recuperer() {

		return null;
	}

}
