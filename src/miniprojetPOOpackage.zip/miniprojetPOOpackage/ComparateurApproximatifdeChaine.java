package miniprojetPOOpackage;

public interface ComparateurApproximatifdeChaine {
	double comparer(String s1, String s2);
    boolean estDistance();

}
