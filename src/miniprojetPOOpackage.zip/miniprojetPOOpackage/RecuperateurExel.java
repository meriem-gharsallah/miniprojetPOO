package miniprojetPOOpackage;

import java.util.List;

public class RecuperateurExel implements RecuperateurDeNoms {

	public RecuperateurExel() {

		
	}
	public  List<Nom> recuperer() {

		return null;
	}

}
