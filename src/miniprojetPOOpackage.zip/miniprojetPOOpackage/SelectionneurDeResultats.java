package miniprojetPOOpackage;

import java.util.List;

public interface SelectionneurDeResultats {
	List<CoupleDeNomsAvecScore> selectionner(List<CoupleDeNomsAvecScore> noms);

}